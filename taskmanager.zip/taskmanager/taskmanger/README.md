## Add these variables in your .env file 

* MONGO_URI=your_mongo_uri
* JWT_SECRET=secret or anything random
* CLIENT_URL=http://localhost:3000 or any localhost port that you are using
* PORT=8000
